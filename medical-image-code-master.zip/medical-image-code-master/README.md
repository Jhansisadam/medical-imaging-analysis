# medical-image-code
the usually used medical image processing codes for deep learning.


metrics including: mae, mse, psnr and ssim.

png_to_npy: convert png images to a npy file.

Unet: simple Unet model which can be used.

2-to-1: create 2 channels npy file.
